<?php 
$name = $_REQUEST['Name'] ;
$email = $_REQUEST['Email'] ;
$message = $_REQUEST['Message'] ;


$message = "Name: $name\nEmail: $email\nmessage : $message" ;

mail("amarmishra0206@gmail.com","You Have Recived", "Information Requested:\n\n$message", "From: $email") ;
Echo "ok sir";

?>